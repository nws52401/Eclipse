function setup() {
  createCanvas(700, 700);
  var yourWeight = 203;
  var marsWeight = calculateMars(yourWeight)
  print(marsWeight);
}

function draw() {
  background(220);
  owl(110,110)
  owl(180,110)
  for (var x = 35; x < width +70; x += 70){
    owl(x,110);
}
 
  function owl(x,y){
  push();
  translate(x,y);
  stroke(0);
  strokeWeight(70);
  line(0,-35,0,-65);
  noStroke();
fill(255);
  ellipse(-17.5, -65, 35, 35); 
  ellipse(17.5, -65, 35, 35); 
  arc(0, -65, 70, 70, 0, PI); 
  fill(0);
  ellipse(-14, -65, 8, 8);
  ellipse(14, -65, 8, 8);
  quad(0, -58, 4, -51, 0, -44, -4, -51)
    pop();
    translate(width / 2, height / 2);
    rotate(PI / 3.0);
rect(0, 0, 55, 55);
rect(0, 0, 55, 55); 
translate(14, 14);
    scale(0.5)
rect(0, 0, 55, 55); 
    angleMode(DEGREES); 
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(width / 2, height / 2);
  push();
  rotate(a);
  pop();
  angleMode(RADIANS); 
  rotate(a); 
}
}
function calculateMars(w) {
  var newWeight = w * 0.38;
  return newWeight;
}