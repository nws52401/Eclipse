let y = 0;
function setup() {
  createCanvas(720,400);
  stroke(255)
  frameRate(30)
  noLoop();
}
  let value = 0;
function draw() {
  background(0);
  
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  rect(250,250,300,300)

y=y - 1;

  if(y<0) {
    y = height
  }
  line(0, y, width, y);
  
  fill(value);
  rect(25, 25, 50, 50);
let a = 4;
if (y >0){
  console.log('positive');
}
else{
  console.log('negative');
}
  for (let i = 0; i < 9; i++) {
  console.log(i);
}
}
function mousePressed (){
  loop();
}

function mouseClicked() {
  if (value === 0) {
    value = 255;
  } else {
    value = 0;
  }
  function mousePressed() {
  ellipse(mouseX, mouseY, 200,200)
  return false;

  function mousePressed(event) {
  console.log(event);
}
  }


  }