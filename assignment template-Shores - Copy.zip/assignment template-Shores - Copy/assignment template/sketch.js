let vid;
function setup() {
  noCanvas();

  vid = createVideo(
    ['assets/Animation Project 1.mp4', 'assets/Animation Project 1.ogv', 'assets/Animation Project 1.webm'],
    vidLoad
  );

  vid.size(600, 600);
}

function vidLoad() {
  vid.loop();
  vid.volume(0);
}